# Enable authentication in your own Node.js web API by using Azure AD B2C

## Resources

Follow the steps in [Enable authentication in your own Node.js web API by using Azure AD B2C](https://docs.microsoft.com/azure/active-directory-b2c/enable-authentication-in-node-web-app-with-api) to learn how to how to create your own web app that calls your own web API that's protected by Azure AD B2C.
